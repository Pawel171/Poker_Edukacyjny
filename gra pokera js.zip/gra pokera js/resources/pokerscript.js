let output = document.getElementById("output");
let cardimg = document.getElementById("cardimg");
let hand = document.getElementById("hand");
let buttons = document.getElementsByClassName("actionbutton")
let slider = document.getElementById("pick")
let slider_p = document.getElementById("slider")
let wylosowane = [[0,0]]

class player{
    constructor(money, name){
        this.money = money
        this.name = name
        this.betted = 0
    }

    turn(action, value){
        if(action==1){
            for(let j=0; j<buttons.length; j++){
                buttons[j].style.backgroundColor = "gray"
                buttons[j].style.borderColor = "rgb(50, 50, 50)"
                buttons[j].setAttribute("disabled", "true")
            }
        }
    }
}

function sprawdz(tablica, tablica_inna){
    for(let i=0; i<tablica.length; i++){
        if(tablica[i].length === tablica_inna.length && 
            tablica[i].every((val, index) => val === tablica_inna[index])){
                return false;}
    }
    return true
}

function randomNumber(rrange) {
    let random = Math.floor(Math.random() * rrange +1);
    return random;
}
function randomCard(wylosowane) {
    let cardNumber = 0; let cardSymbol = 0;
    while(sprawdz(wylosowane, [cardNumber, cardSymbol])==false){
    cardNumber = randomNumber(13);
    if (cardNumber == 1) {
        cardNumber = "ace";
    }
    else if (cardNumber == 11) {
        cardNumber = "jack";
    }
    else if (cardNumber == 12) {
        cardNumber = "queen";
    }
    else if (cardNumber == 13) {
        cardNumber = "king";
    }
    else {
        cardNumber = cardNumber}
    cardSymbol = randomNumber(4);
    if (cardSymbol == 1) {
        cardSymbol = "heart";
    }
    else if (cardSymbol == 2) {
        cardSymbol = "spade";
    }
    else if (cardSymbol == 3) {
        cardSymbol = "diamond";
    }
    else if (cardSymbol == 4) {
        cardSymbol = "club";
    }}
    return [cardNumber, cardSymbol]
}

function cardAdd(ilosc, place) {
    if(place=="cardimg"){
    if(cardimg.children.length==3 || cardimg.children.length==4){
        ilosc = 1 
    }
    if(cardimg.children.length==5 || cardimg.children.length==1){
    cardimg.innerHTML = ""}
    for(let i=0; i<ilosc; i++){
    image = document.createElement("img")
    let karta = randomCard(wylosowane)
    image.src = "resources/cards/" + karta[1] + "/" + karta[0] + ".PNG"
    image.style.width = "100px"
    cardimg.appendChild(image)
    wylosowane.push(karta)}}

    if(place=="hand"){
        hand.innerHTML = ""
        for(let i=0; i<2; i++){
        image = document.createElement("img")
        let karta = randomCard(wylosowane)
        image.src = "resources/cards/" + karta[1] + "/" + karta[0] + ".PNG"
        image.style.width = "100px"
        hand.appendChild(image)
        wylosowane.push(karta)}}
}

let placed = 1000
let player1 = new player(10000, "Ja")
slider_p.addEventListener("input", function(){
    document.getElementById("text_slider").innerHTML = "<br><br><br>" + slider.value
})
cardAdd(1, "cardimg");
cardAdd(2, "hand")
cardimg.addEventListener("click", function(){
    cardAdd(3, "cardimg");
})
for(let i=0; i<buttons.length; i++){
    buttons[i].addEventListener("click", () => {
        if(buttons[i].disabled = "true"){
            let qwertyuiop = 0
        }
        else if(buttons[i].id=="fold"){
            player1.turn(1, 0)
        }
        else if(buttons[i].id=="check"){
            player1.turn(3, 0)
        }
        else if(buttons[i].id=="call"){
            player1.turn(4, placed)
        }
        else if(buttons[i].id=="hit"){
            player1.turn(4, placed)
        }
        console.log("You clicked", buttons[i].id, "!")
    })
}
