var rouletteimg = document.getElementById("rouletteimg");
var output = document.getElementById("output");

function randomNumber(rrange) {
    let random = Math.floor(Math.random() * rrange +1);
    return random;
}
function randomRouletteNumber() {
    let random = (randomNumber(37)-1);
    return random;
}
function randomRouletteColor() {
    if (rouletteNumber==0) {
        return "green";
    }
    else if (rouletteNumber%2) {
        return "red";
    }
    else {
        return "black";
    }
}

let rouletteNumber = randomRouletteNumber();
let rouletteColor = randomRouletteColor();
output.innerHTML = rouletteNumber +" "+ rouletteColor;

rouletteimg.addEventListener("click", function() {
    rouletteNumber = randomRouletteNumber();
    rouletteColor = randomRouletteColor();
    output.innerHTML = rouletteNumber +" "+ rouletteColor;
});