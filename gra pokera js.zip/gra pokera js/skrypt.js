var stawka = document.getElementById("stawka")
let wyswietlacz = document.getElementById("wyswietlacz")
stawka.addEventListener("input", function(){
    wyswietlacz.innerHTML = stawka.value
})
var komunikator = document.getElementById("komunikat")
var guziory = document.getElementById("guziory")
var komunikaty = []
var pieniadze_miejsce = document.getElementById("pieniadze")
var stawka_wyswietl = document.getElementById("stawka_wyswietl")
var karty_g = document.getElementById("karty")
var czas2 = document.getElementById("czas")
var wygrana = document.getElementById("zwyciezca")
var uklady_miejsce = document.getElementById("uklady")

function translate(karty, width, height){
    console.log(karty, "ZOBACZ TUTAJ")
    let query = ""; let number = ""; let symbol = ""; let path = ""; let pass = false
    if(karty.length!=0){
        if(typeof(karty)=="string"){
            path = "resources\\cards\\"
            if(karty.slice(-1)=="C"){
                path += "club"
            }
            if(karty.slice(-1)=="H"){
                path += "heart"
            }
            if(karty.slice(-1)=="S"){
                path += "spade"
            }
            if(karty.slice(-1)=="D"){
                path += "diamond"
            }
            path += "\\" + karty.slice(0, -1) + ".png"
            query = "<img widht='" + width + "' height='" + height + "' src='" + path + "'>"
            return query
        }
        for(let i=0; i<karty.length; i++){
            path = "resources\\cards\\"
            if(pass==true){
                number = karty.slice(0, -1)
                symbol = karty.slice(-1)
            }
            else{
                number = karty[i].slice(0, -1)
                symbol = karty[i].slice(-1)
            }
            if(symbol=="C"){
                path += "club"
            }
            if(symbol=="H"){
                path += "heart"
            }
            if(symbol=="S"){
                path += "spade"
            }
            if(symbol=="D"){
                path += "diamond"
            }
            path += "\\" + number + ".png"
            query += "<img widht='" + width + "' height='" + height + "' src='" + path + "'>"
        }
        return query
    }
    else{
        console.log("nie ma kart")
        return ""
    }
}

function czekajNaKlik(przycisk) {
    return new Promise(resolve => {
        function klik() {
            przycisk.removeEventListener("click", klik);
            uklady_miejsce.innerHTML = ""
            resolve();
        }
        przycisk.addEventListener("click", klik);
    });
}

function all(community_cards, hands){
    community_cards = [...community_cards]
    console.log(hands, "ghghghhgghghgh tutaj jest coś")
    hands = hands.map(sublist => [...sublist])
    hands = hands.slice(-3)

    function split(card){
        let number = Number(card.slice(0, -1)); let symbol = card.slice(-1);
        return {number, symbol}
    }

    let uklady_graczy = []
    for(let i=0; i<hands.length; i++){
        let uklady = []
        let all_cards = [...community_cards, hands[i][0], hands[i][1]]
        hands[i] = hands[i].map((x) => Number(x.slice(0, -1)))
        let high_card, low_card
        if(hands[i][0]>hands[i][1]){
            high_card = hands[i][0]
            low_card = hands[i][1]
        }
        else{
            high_card = hands[i][1]
            low_card = hands[i][0]
        }
        let splitted_card = [...(all_cards.map((x) => split(x)))]
        splitted_card = splitted_card.sort((a, b) => a.number-b.number)
        let numbers = [...(splitted_card.map((x) => x.number))]; let symbols = [...(splitted_card.map((x) => x.symbol))]
        if(numbers.includes(10)){
            let symbol = symbols[numbers.indexOf(10)]
            if([11, 12, 13, 14].every(el => numbers.includes(el))){
                let symbole = [11, 12, 13, 14].map((x) => symbols[numbers.indexOf(x)])
                    if(symbole.every(el => el==symbol)){
                    uklady.push([" Poker królewski ", 10])
                }
            }
        }
        let counter = 1
        for(let i=1; i<numbers.length; i++){
            if(numbers[i]==numbers[i-1]+1){
                counter++
            }
            if(counter==5){
                let symbol = symbols[i]
                if([i-1, i-2, i-3, i-4].every(el => symbols[el]==symbol)){
                    uklady.push([" Poker ", 9])
                }
                else{
                    uklady.push([" Strit ", 5])
                }
            }
            if(numbers[i]!=numbers[i-1]+1 && numbers[i]!=numbers[i-1]){
                counter = 1
            }
        }
        let symbole_d = ["D", "H", "S", "C"]
        let frequencies_s = []
        for(let i=0; i<4; i++){
            let counter_s = 0
            for(let j=0; j<symbols.length; j++){
                if(symbols[j]==symbole_d[i]){
                    counter_s++
                }
            }
            frequencies_s.push(counter_s)
        }
        if(frequencies_s.includes(5) || frequencies_s.includes(6) || frequencies_s.includes(7)){
            uklady.push([" Kolor ", 6])
        }
        let frequencies = []
        for(let j=2; j<15; j++){
            let counter = 0
            for(let k=0; k<numbers.length; k++){
                if(numbers[k]==j){
                    counter++
                }
            }
            frequencies.push(counter)
        }
        if(frequencies.includes(4) || frequencies.includes(5) || frequencies.includes(6) || frequencies.includes(7)){
            uklady.push([" Kareta ", 8])
        }
        if(frequencies.includes(3)){
            if(frequencies.includes(2)){
                uklady.push([" Full House ", 7])
            }
            uklady.push([" Trójka ", 4])
        }
        if(frequencies.includes(2)){
            frequencies[frequencies.indexOf(2)]=0
            if(frequencies.includes(2)){
                uklady.push([" Dwie pary ", 3])
            }
            uklady.push([" Para ", 2])
        }
        uklady.push([" Wysoka karta ", 1])
        uklady.sort((a, b) => a[1] - b[1])
        uklady_graczy.push([uklady[uklady.length-1][1], high_card, low_card, i, uklady[uklady.length-1][0]])
    }
    return uklady_graczy
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function pick_element(lista){
    let index = Math.floor(Math.random() * lista.length)
    return lista[index]
}

function change_log(lista, komunikat) {
    if(lista.length>=10){
        lista.shift()
        lista.push(komunikat)
    }
    else{
        lista.push(komunikat)
    }
    komunikator.innerHTML = ""
    for(let i=0; i<lista.length; i++){
        komunikator.innerHTML += lista[i] + "<br>"
    }
}

class Game{
    constructor(nazwa_gracza, ilosc_graczy, stawka_poczatkowa){
        this.ilosc = ilosc_graczy
        this.komunikaty = []
        this.stawka = stawka_poczatkowa
        this.initial = 10
        this.pool = 0
        this.gracze = []
        this.cards = []
        this.gracze_fine = []
        this.winner = -1
        for(let i=0; i<this.ilosc-1; i++){
            this.gracze.push(new Bot(i, this.stawka))
            this.gracze_fine.push(i)
        }
        this.gracze.push(new Gracz(nazwa_gracza, this.stawka))
        this.gracze_fine.push(this.ilosc-1)
        let suits = ["D", "S", "H", "C"]
        let numbers = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
        this.deck = []
        for(let i=0; i<suits.length; i++){
            for(let j=0; j<numbers.length; j++){
                this.deck.push(numbers[j]+suits[i])
            }
        }
        this.deck_a = [...this.deck]
    }

    setup(){
        console.log("SETUP")
        this.gracze_fine = []
        this.cards = []; this.cards2 = []
        this.winner = -1
        for(let i=0; i<this.gracze.length; i++){
            this.gracze_fine.push(i)
            this.gracze[i].unfold()
            this.cards.push([...this.random_card(2)])
            console.log(this.cards, i)
        }
        this.cards2 = structuredClone(this.cards)
        this.pool = 0
    }

    radom(min, max){
        return Math.floor(Math.random()*(max-min+1)+min)
    }

    random_card(how_many){
        let Cards = []
        if(this.deck_a.length<how_many){
            this.deck_a = [...this.deck]
        }
        for(let i=0; i<how_many; i++){
            let card = this.deck_a[this.radom(0, this.deck_a.length-1)]
            Cards.push(card)
            let index = this.deck_a.indexOf(card)
            this.deck_a.splice(index, 1)
        }
        if(how_many==1){
            return Cards[0]
        }
        else{
            return Cards
        }
    }

    async turn(community_cards){
        console.log(this.gracze)
        karty_g.innerHTML = translate(this.cards[this.cards.length-1][0], 80, 110) + translate(this.cards[this.cards.length-1][1], 80, 110) + "<br>" + translate(community_cards, 50, 80)
        for(let i=0; i<this.gracze.length; i++){
            let still_playing = 0
            let indoks = -1
            let action; let stake = 0
            for(let i=0; i<this.gracze.length; i++){
                if(this.gracze[i].return_values()[2]==false){
                    still_playing++
                    indoks = i
                }
            }
            if(still_playing==1){
                break
            }
            if(this.gracze[i].return_values()[2]==false){
                await sleep(1500)
            if(i==0){
                this.stake=this.initial
            }
            if(this.gracze[i].return_values()[1]<this.stake){
                action = 0
            }
            else{
                stawka.min = this.stake*2
                let decision
                let status = "call"
                if(this.gracze_fine.includes(i)){
                    status = "check"
                }
                try{
                    decision = await this.gracze[i].decide(this.stake, status)
                }
                catch(error){
                    decision = error
                }
                action = decision[0]
                stake = decision[1]
            }
            if(action==0){
                change_log(this.komunikaty, this.gracze[i].return_values()[3] + " numer. " + this.gracze[i].return_values()[0] + " Zpasował!")
                this.gracze[i].fold()
            }
            if(action==1){
                change_log(this.komunikaty, this.gracze[i].return_values()[3] + " numer. " + this.gracze[i].return_values()[0] + " Użył check!")
            }
            if(action==2){
                change_log(this.komunikaty, this.gracze[i].return_values()[3] + " numer. " + this.gracze[i].return_values()[0] + " Postawił obowiązkową ilość!")
                this.gracze[i].bet(this.stake)
                this.pool += Number(stake)
                this.gracze_fine.push(i)
            }
            if(action==3){
                change_log(this.komunikaty, this.gracze[i].return_values()[3] + " numer. " + this.gracze[i].return_values()[0] + " Podbił stawkę o " + stake + " żetonów")
                for(let j=0; j<this.gracze.length; j++){
                    
                }
                this.gracze[i].bet(stake+this.stake)
                this.pool += stake
                this.stake = this.stake+stake
                stawka.min = this.stake*2
                this.gracze_fine = [i]
            }
            }
            this.filter()
            stawka_wyswietl.innerHTML = this.stake + " to aktualna opłata " + "<br>" + this.pool + " w puli jest"
        }
        return 0
    }

    initial_round(community_cards){
        karty_g.innerHTML = this.cards[this.cards.length-1] + "<br>" + community_cards
        for(let i=0; i<this.gracze.length; i++){
            this.cards.push([...this.random_card(2)])
            this.gracze[i].bet(this.initial)
            if(this.gracze[i].return_values()[1]<0){
                change_log(this.komunikaty, this.gracze[i].return_values()[0] + " zbankrutował")
                this.gracze[i] = 0
            }
            this.pool+=this.initial
        }
        change_log(this.komunikaty, "Postawiono początkowe " + this.initial + " żetonów!")
        stawka.max = this.gracze[this.gracze.length-1].return_values()[1]
        this.filter()
        this.cards2 = structuredClone(this.cards)
    }

    async final_showdown(community_cards, winner){
        console.log(this.cards, "karty pierwsze")
        console.log(this.cards2, "karty drugie")
        let wyniki = all(community_cards, this.cards2)
        if(0==0){
            console.log(community_cards)
            for(let i=0; i<wyniki.length; i++){
                console.log(wyniki[i][3])
                console.log(wyniki, "tutaj")
                console.log(this.cards, "tutaj też")
                console.log(this.gracze[wyniki[i][3]].return_values()[2], "KTOŚ ZFLODOWAŁ")
                if(this.gracze[wyniki[i][3]].return_values()[2]==true){
                    wyniki[i][0] = -100
                    console.log("ktoś FLODOWAŁ")
                }
            }
            console.log(wyniki)
            wyniki.sort((a, b) => {
                let porownanie = a[0] - b[0]
                if(porownanie!==0){
                    return porownanie
                }
                else{
                    let porownanie1 = a[1]-b[1]
                    if(porownanie1!==0){
                        return porownanie1
                    }
                    else{
                        return a[2]-b[2]
                    }
                }
            })
        let wygrany = wyniki[wyniki.length-1]
        console.log(wygrany[3])
        wygrana.style.display = "block"
        wygrana.innerHTML = "Tą rundę wygrał: " + this.gracze[wygrany[3]].return_values()[3] + " " + this.gracze[wygrany[3]].return_values()[0] + "!"
        this.gracze[wygrany[3]].pay(this.pool)
        for(let i=0; i<wyniki.length; i++){
            uklady_miejsce.innerHTML += this.gracze[wyniki[i][3]].return_values()[3] + " " + this.gracze[wyniki[i][3]].return_values()[0] + " miał układ " + wyniki[i][4] +  " i miał karty " + translate(this.cards[wyniki[i][3]], 30, 50) + "<br>"
        }
        setTimeout(() => {
            this.setup()
            wygrana.style.display = "none"
            wygrana.innerHTML = ""
        }, 3000);
        return 0
        }
    }

    filter(){
        pieniadze_miejsce.innerHTML = ""
        for(let i=0; i<this.gracze.length; i++){
            pieniadze_miejsce.innerHTML += this.gracze[i].return_values()[3] + " " + this.gracze[i].return_values()[0] + " ma " + this.gracze[i].return_values()[1] + " pieniędzy!<br>"
        }
        /*while(this.gracze.indexOf(0)!=-1){
            let index = this.gracze.indexOf(0)
            this.gracze.splice(index, 1)
            this.cards.splice(index, 1)
        }*/
    }

    return_values(){
        return [this.gracze, this.deck, this.deck_a, this.pool]
    }
}

class Gracz{
    constructor(nazwa, stawka_poczatkowa){
        this.nazwa = nazwa
        this.pieniadze = stawka_poczatkowa
        this.has_folded = false
    }

    radom(min, max){
        return Math.floor(Math.random()*(max-min+1)+min)
    }

    fold(){
        this.has_folded = true
    }

    unfold(){
        this.has_folded = false
    }

    bet(money){
        this.pieniadze -= money
    }

    pay(money){
        this.pieniadze += money
    }

    return_values(){
        return [1, this.pieniadze, this.has_folded, this.nazwa]
    }

    decide(stake, status){
        let message
        if(status=="call"){
            message = "<button class='decision' value='2' style='border: solid black 3px;'>Call</button>"
        }
        if(status=="check"){
            message = "<button class='decision' value='1' style='border: solid black 3px;'>Check</button>"
        }
        guziory.innerHTML += "<button class='decision' value='0' style='border: solid black 3px; border-top-left-radius: 25px; border-bottom-left-radius: 25px;'>Fold</button>" + message + "<button class='decision' value='3' style='border: solid black 3px; border-top-right-radius: 25px; border-bottom-right-radius: 25px;'>Raise</button>"
        let przyciski = document.getElementsByClassName("decision")
        let action = 0
        let pass = false
        let timee = 30000
        let czas_pozostal = timee
        let stakes = stake
        stawka.max = this.pieniadze
        if(stake*2>this.pieniadze){
            wyswietlacz.innerHTML = "Nie możesz podbijać, możesz tylko zagrać All-In"
        }
        let zatrzymaj = new AbortController()
        let sygnal = zatrzymaj.signal
        let timer = setInterval(() => {
            czas_pozostal -= 1000
            czas2.innerHTML = "Pozostało czasu na decyzje: " + Math.floor(czas_pozostal/1000)
            if(czas_pozostal==0){
                clearInterval(timer)
            }
        }, 1000);
        return new Promise((resolve, reject) => {
            let czas = setTimeout(() => {
                if(!pass){
                    guziory.innerHTML = ""
                    reject([0, 0])
                }
            }, timee);

            function handle_click(event){
                clearInterval(timer)
                pass = true
                clearTimeout(czas)
                action = event.target.value
                stawka.min = stawka
                stawka.max = this.pieniadze
                stakes = stawka.value
                resolve([action, Number(stakes)])
                zatrzymaj.abort()
                guziory.innerHTML = ""
            }

            for(let i=0; i<przyciski.length; i++){
                przyciski[i].addEventListener("click", handle_click, {signal : sygnal})
            }
        })
    }
}

class Bot{
    constructor(id, stawka_poczatkowa){
        this.id = id
        this.name = "Bot"
        this.pieniadze_g = stawka_poczatkowa
        this.has_folded = false
    }

    radom(min, max){
        return Math.floor(Math.random()*(max-min+1)+min)
    }

    fold(){
        this.has_folded = true
    }

    unfold(){
        this.has_folded = false
    }

    bet(money){
        this.pieniadze_g -= money
    }

    pay(money){
        this.pieniadze_g += money
    }

    return_values(){
        return [this.id, this.pieniadze_g, this.has_folded, this.name]
    }

    decide(stake, status){
        let action
        if(status=="call"){
            action = pick_element([-0, 2, 2, 2, 3, 3])    
        }
        if(status=="check"){
            action = pick_element([0, 1, 1, 1, 1, 3, 3])
        }
        let number = this.radom(Number(stake)+1, Math.floor(this.pieniadze_g/5))-Number(stake)
        if(Number(stake)+1>Math.floor(this.pieniadze_g/5)){
            action = 0
        }
        //let number = 20
        return [action, number]
    }
}


/*async function dane(){
    let myPromise = new Promise(function(resolve, reject) {
    let zacznij = document.getElementById("zacznij")
    zacznij.addEventListener("click", function(){
    var nazwa_gracza = document.getElementById("nazwa")
    var ilosc_graczy = document.getElementById("ilosc")
    document.innerHTML = ""
    let pola = document.getElementsByTagName("div")
    let pole = document.getElementById("stawka")
    let do_wywalenia = document.getElementsByClassName("wywalaj")
    for(let i=0; i<do_wywalenia.length; i++){
        do_wywalenia[i].style.display = "none"
    }
    for(let i=0; i<pola.length; i++){
        pola[i].style.display = "block"
    }
    pole.style.display = "block"
})

    if (nazwa_gracza) {
    myResolve("OK");}
})}*/

async function poker_game(){
    let Gra = new Game("Pawel", 5, 1000)
    let community_cards = []
    let gracz_wygrany
    let tura = document.getElementById("nastepna_tura")
    for(let i=0; i<3; i++){
        gracz_wygrany = undefined
        community_cards = []
        Gra.initial_round(community_cards)
        gracz_wygrany = await Gra.turn(community_cards)
        community_cards.push(...Gra.random_card(3))
        gracz_wygrany = await Gra.turn(community_cards)
        community_cards.push(Gra.random_card(1))
        gracz_wygrany = await Gra.turn(community_cards)
        community_cards.push(Gra.random_card(1))
        gracz_wygrany = await Gra.turn(community_cards)
        await Gra.final_showdown(community_cards, gracz_wygrany)
        setTimeout(() => {
            community_cards = []
            console.log("ghghhgh")
            wygrana.innerHTML = ""
        }, 4000);
        tura.style.display = "block"
        tura.style.left = "70%"
        console.log("przycisk ez")
        console.log(tura.style.display)
        await czekajNaKlik(tura)
        tura.style.display = "none"
    }
    koniec()
}

poker_game()
function koniec(){
    wygrana.innerHTML = "To koniec"
}
